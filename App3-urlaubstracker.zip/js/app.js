// ===== Urlaubstracker – Hauptlogik =====

const TILES = {
  light: 'https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png',
  dark:  'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png'
};
const TILE_ATTR =
  '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="https://carto.com/attributions">CARTO</a>';

const state = {
  map: null,
  tileLayer: null,
  markers: {},        // id -> L.marker
  pins: [],           // alle Pins
  placing: null,      // null | 'ziel' | 'besucht'
  filter: 'alle',     // alle | ziel | besucht
  theme: localStorage.getItem('ut_theme') || 'light'
};

// ---------- Pin-Icon (farbige Stecknadel als SVG) ----------
function pinIcon(type) {
  const fill = type === 'besucht' ? '#22a559' : '#f5b81a';
  const stroke = type === 'besucht' ? '#157a3e' : '#b6850a';
  const svg = `
    <svg width="30" height="42" viewBox="0 0 30 42" xmlns="http://www.w3.org/2000/svg">
      <path d="M15 1C7.3 1 1 7.2 1 15c0 9.8 12 24.5 13 25.6.5.6 1.5.6 2 0C17 39.5 29 24.8 29 15 29 7.2 22.7 1 15 1z"
            fill="${fill}" stroke="${stroke}" stroke-width="1.5"/>
      <circle cx="15" cy="15" r="5.5" fill="#ffffff" fill-opacity="0.9"/>
    </svg>`;
  return L.divIcon({
    className: 'pin-marker',
    html: svg,
    iconSize: [30, 42],
    iconAnchor: [15, 41],
    popupAnchor: [0, -36]
  });
}

// ---------- Karte ----------
function initMap() {
  state.map = L.map('map', {
    center: [30, 10],
    zoom: 2,
    minZoom: 2,
    maxZoom: 18,
    worldCopyJump: true,
    zoomControl: true
  });
  state.tileLayer = L.tileLayer(TILES[state.theme], {
    attribution: TILE_ATTR,
    subdomains: 'abcd',
    maxZoom: 20
  }).addTo(state.map);

  state.map.on('click', onMapClick);
}

function setTheme(theme) {
  state.theme = theme;
  localStorage.setItem('ut_theme', theme);
  document.documentElement.setAttribute('data-theme', theme);
  if (state.tileLayer) state.tileLayer.setUrl(TILES[theme]);
  const btn = document.getElementById('btn-theme');
  if (btn) btn.textContent = theme === 'dark' ? '☀️' : '🌙';
}

// ---------- Setzen-Modus ----------
function startPlacing(type) {
  if (state.placing === type) { stopPlacing(); return; }
  state.placing = type;
  document.getElementById('map').classList.add('placing');
  updatePlacingHint();
  setActiveAddButtons();
}
function stopPlacing() {
  state.placing = null;
  document.getElementById('map').classList.remove('placing');
  updatePlacingHint();
  setActiveAddButtons();
}
function setActiveAddButtons() {
  document.getElementById('btn-ziel').classList.toggle('active', state.placing === 'ziel');
  document.getElementById('btn-besucht').classList.toggle('active', state.placing === 'besucht');
}
function updatePlacingHint() {
  const hint = document.getElementById('placing-hint');
  if (!state.placing) { hint.style.display = 'none'; return; }
  hint.style.display = 'block';
  hint.textContent = state.placing === 'ziel'
    ? '📍 Tippe auf die Karte, um ein Ziel (gelb) zu setzen'
    : '📍 Tippe auf die Karte, um einen besuchten Ort (grün) zu setzen';
}

function onMapClick(e) {
  if (!state.placing) return;
  const type = state.placing;
  stopPlacing();
  openPinForm(null, { lat: e.latlng.lat, lng: e.latlng.lng, type });
}

// ---------- Marker rendern ----------
function clearMarkers() {
  Object.values(state.markers).forEach(m => state.map.removeLayer(m));
  state.markers = {};
}
function pinVisible(p) {
  return state.filter === 'alle' || state.filter === p.type;
}
function renderMarkers() {
  clearMarkers();
  state.pins.filter(pinVisible).forEach(addMarker);
}
function addMarker(p) {
  const m = L.marker([p.lat, p.lng], { icon: pinIcon(p.type) }).addTo(state.map);
  m.on('click', () => openPinPopup(p.id));
  state.markers[p.id] = m;
}

// ---------- Daten laden ----------
async function loadPins() {
  state.pins = await dbGetAll('pins');
  renderMarkers();
  renderList();
}

// ---------- Pin-Formular (neu / bearbeiten) ----------
function openPinForm(id, preset) {
  const p = id ? state.pins.find(x => x.id === id) : null;
  const type = p ? p.type : preset.type;
  const year = p ? p.year : new Date().getFullYear();
  const note = p ? p.note : '';
  const lat = p ? p.lat : preset.lat;
  const lng = p ? p.lng : preset.lng;

  const body = `
    <div class="form-group">
      <label>Art</label>
      <div class="seg">
        <button type="button" class="seg-btn ${type === 'ziel' ? 'on' : ''}" data-type="ziel"
          onclick="formSetType('ziel')">🟡 Ziel</button>
        <button type="button" class="seg-btn ${type === 'besucht' ? 'on' : ''}" data-type="besucht"
          onclick="formSetType('besucht')">🟢 Besucht</button>
      </div>
    </div>
    <div class="form-group">
      <label>Urlaubsjahr</label>
      <input type="number" id="pf-year" value="${year}" min="1900" max="2100" step="1">
    </div>
    <div class="form-group">
      <label>Notiz</label>
      <textarea id="pf-note" rows="3" placeholder="z.B. Strandurlaub, Städtetrip ...">${escHtml(note)}</textarea>
    </div>
    <div class="modal-actions">
      ${id ? `<button class="btn danger" onclick="deletePin(${id})" style="margin-right:auto">Löschen</button>` : ''}
      <button class="btn ghost" onclick="closeModal()">Abbrechen</button>
      <button class="btn primary" onclick="savePin(${id || 'null'}, ${lat}, ${lng})">Speichern</button>
    </div>
  `;
  openModal(id ? 'Markierung bearbeiten' : 'Neue Markierung', body);
  state._formType = type;
}

function formSetType(t) {
  state._formType = t;
  document.querySelectorAll('.seg-btn').forEach(b =>
    b.classList.toggle('on', b.dataset.type === t));
}

async function savePin(id, lat, lng) {
  const year = parseInt(document.getElementById('pf-year').value) || new Date().getFullYear();
  const note = document.getElementById('pf-note').value.trim();
  const type = state._formType || 'ziel';
  const existing = id ? state.pins.find(x => x.id === id) : null;
  const obj = {
    id: id || undefined,
    lat, lng, type, year, note,
    createdAt: existing ? existing.createdAt : Date.now()
  };
  await dbPut('pins', obj);
  closeModal();
  showToast(id ? 'Markierung gespeichert' : 'Markierung gesetzt');
  await loadPins();
}

async function deletePin(id) {
  if (!confirm('Diese Markierung löschen?')) return;
  await dbDelete('pins', id);
  closeModal();
  showToast('Markierung gelöscht');
  await loadPins();
}

// ---------- Popup beim Antippen eines Pins ----------
function openPinPopup(id) {
  const p = state.pins.find(x => x.id === id);
  if (!p) return;
  const m = state.markers[id];
  const label = p.type === 'besucht' ? '🟢 Besucht' : '🟡 Ziel';
  const note = p.note ? `<div class="pop-note">${escHtml(p.note)}</div>` : '';
  const toGreen = p.type === 'ziel'
    ? `<button class="btn primary sm" onclick="markVisited(${id})">Als besucht ✓</button>` : '';
  const html = `
    <div class="pop">
      <div class="pop-head">${label} · ${p.year}</div>
      ${note}
      <div class="pop-actions">
        ${toGreen}
        <button class="btn ghost sm" onclick="openPinForm(${id})">Bearbeiten</button>
      </div>
    </div>`;
  m.bindPopup(html, { closeButton: true }).openPopup();
}

async function markVisited(id) {
  const p = state.pins.find(x => x.id === id);
  if (!p) return;
  p.type = 'besucht';
  await dbPut('pins', p);
  state.map.closePopup();
  showToast('Ziel als besucht markiert');
  await loadPins();
}

// ---------- Filter ----------
function setFilter(f) {
  state.filter = f;
  document.querySelectorAll('.chip').forEach(c =>
    c.classList.toggle('on', c.dataset.filter === f));
  renderMarkers();
  renderList();
}

// ---------- Liste (Seitenpanel) ----------
function toggleList() {
  document.getElementById('panel').classList.toggle('open');
}
function renderList() {
  const el = document.getElementById('list');
  if (!el) return;
  const pins = state.pins.filter(pinVisible)
    .sort((a, b) => (b.year - a.year) || (b.createdAt - a.createdAt));
  const cnt = {
    alle: state.pins.length,
    ziel: state.pins.filter(p => p.type === 'ziel').length,
    besucht: state.pins.filter(p => p.type === 'besucht').length
  };
  document.getElementById('count-besucht').textContent = cnt.besucht;
  document.getElementById('count-ziel').textContent = cnt.ziel;

  if (pins.length === 0) {
    el.innerHTML = `<div class="empty">Noch keine Markierungen.<br>
      Tippe oben auf „Ziel" oder „Besucht" und dann auf die Karte.</div>`;
    return;
  }
  el.innerHTML = pins.map(p => `
    <div class="list-item" onclick="flyTo(${p.id})">
      <span class="dot ${p.type}"></span>
      <div class="li-body">
        <div class="li-top"><b>${p.type === 'besucht' ? 'Besucht' : 'Ziel'}</b>
          <span class="li-year">${p.year}</span></div>
        ${p.note ? `<div class="li-note">${escHtml(p.note)}</div>` : ''}
      </div>
    </div>`).join('');
}

function flyTo(id) {
  const p = state.pins.find(x => x.id === id);
  if (!p) return;
  if (window.innerWidth < 720) document.getElementById('panel').classList.remove('open');
  state.map.flyTo([p.lat, p.lng], Math.max(state.map.getZoom(), 6), { duration: 0.8 });
  setTimeout(() => openPinPopup(id), 850);
}

// ---------- Modal / Toast / Utils ----------
function openModal(title, bodyHtml) {
  document.getElementById('modal-title').textContent = title;
  document.getElementById('modal-body').innerHTML = bodyHtml;
  document.getElementById('modal-backdrop').classList.add('open');
}
function closeModal() {
  document.getElementById('modal-backdrop').classList.remove('open');
}
let _toastT;
function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(_toastT);
  _toastT = setTimeout(() => t.classList.remove('show'), 2200);
}
function escHtml(s) {
  return String(s ?? '').replace(/[&<>"']/g, c =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

// ---------- Export / Import ----------
async function exportData() {
  const pins = await dbGetAll('pins');
  const blob = new Blob([JSON.stringify({ version: 1, pins }, null, 2)],
    { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'urlaubstracker-backup.json';
  a.click();
  URL.revokeObjectURL(a.href);
}
function importData(file) {
  const r = new FileReader();
  r.onload = async () => {
    try {
      const data = JSON.parse(r.result);
      const pins = Array.isArray(data) ? data : (data.pins || []);
      for (const p of pins) {
        const { id, ...rest } = p;       // neue IDs vergeben -> kein Überschreiben
        await dbPut('pins', rest);
      }
      showToast(`${pins.length} Markierungen importiert`);
      await loadPins();
    } catch (e) { showToast('Import fehlgeschlagen'); }
  };
  r.readAsText(file);
}

// ---------- Start ----------
window.addEventListener('DOMContentLoaded', async () => {
  setTheme(state.theme);
  initMap();
  await loadPins();

  document.getElementById('modal-backdrop').addEventListener('click', (e) => {
    if (e.target.id === 'modal-backdrop') closeModal();
  });

  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('sw.js').catch(() => {});
  }
});
